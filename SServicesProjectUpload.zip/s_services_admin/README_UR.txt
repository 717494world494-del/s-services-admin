S SERVICES — Admin Panel (Enhanced Starter)
===========================================

اس اپ میں شامل فیچرز:
- Dashboard metrics اور management shortcuts
- Users، deposits، withdrawals، payment methods، promotions، IDs، links اور support messages کی مقامی مینجمنٹ
- Approve / reject actions، admin activity log، reports اور JSON backup export
- سات themes: Dark, Light, Green, Purple, Ocean Blue, Sunset Orange, Rose Pink
- English اور Urdu language selector (موجودہ ڈیمو میں بنیادی UI ترجمہ)
- S SERVICES کے لیے built-in S logo اور نیا logo upload / restore کرنے کا آپشن
- موبائل فرینڈلی responsive layout

HTML Demo:
assets/index.html

Android WebView entry point:
app/src/main/assets/index.html

Logo asset:
assets/s_services_logo.svg

ضروری نوٹ:
یہ ایک starter/demo ہے۔ ریکارڈ اسی ڈیوائس/براؤزر کی local storage میں محفوظ ہوتے ہیں۔ یہ live production system نہیں، اور اس میں ابھی cloud database، secure admin authentication، server-side permissions یا حقیقی payment gateway integration شامل نہیں۔ حقیقی کلائنٹ ڈیٹا اور متعدد ڈیوائسز پر sync کے لیے محفوظ backend درکار ہوگا۔

APK بنانے کے لیے Android Studio اور Android SDK/Gradle والا ماحول درکار ہے۔ اس ماحول میں compiled APK تیار نہیں ہوئی؛ ZIP میں source project ہے، APK نہیں۔ Android Studio میں project کھول کر Gradle sync کریں اور Build > Build APK(s) استعمال کریں۔
